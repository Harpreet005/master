<?php
//Database Configuration
$hostname = "localhost";
$user = "root";
$password = "softweaver";
$database = "codebos";
$prefix = "";
//Loadmore configuarion
$resultsPerPage=5;

$con = mysqli_connect($hostname,$user, $password,$database);

?>